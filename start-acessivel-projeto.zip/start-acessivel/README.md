# Start Acessível

Projeto demonstrativo de uma plataforma de aulas com foco em inclusão social e acessibilidade.

## Como usar
1. Abra `index.html` no navegador.
2. Pesquise e filtre as aulas.
3. Marque aulas como concluídas; o progresso fica salvo no navegador.
4. Use o botão de acessibilidade para alternar contraste.

## Publicar para obter um link
Envie o arquivo `index.html` para um repositório GitHub e ative **Settings > Pages > Deploy from a branch > main / root**. O GitHub Pages fornecerá um endereço público terminado em `github.io`.
